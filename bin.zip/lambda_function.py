import json
import request 
import logging
import os
 
# Configurar logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Configurar el URL 
API_URL = os.getenv('API_URL')

# Buscar personajes 
def buscar_personajes():
    # Agregar sufijo a la url almacenada
    url = API_URL + '/character'
    
    # Realizar consulta
    try:
        response = request.get(url)
        response.raise_for_status()
        #Retornar respuesta
        return response.json()
    except request.exceptions.RequestException as e:
        logger.error(f' Ha ocurrido un error al realizar la consula: {e}')
        raise 

# Procesar personajes:
def procesar_personajes(datos):
    # Extrae los datos más relevantes de los personajes
    try: 
        # Procesa los datos de los personajes, si no hay información disponible
        # retorna un valor "desconocido"
        personajes = [{
            'name': character.get('name', 'Unknown name'),
            'status': character.get('status', 'Unknown status'),
            'species': character.get('species', 'Unknown specie'),
            'type': character.get('type', 'Unknown type'),
            'gender': character.get('gender', 'Unknown gender'),
            'origin': {
                'name': character.get('origin', {}).get('name', 'Unknown Origin name'),
                'url': character.get('origin', {}).get('url', 'Unknown URL')
            },
            'location': {
                'name': character.get('location', {}).get('name', 'Unknown location name'),
                'url': character.get('location', {}).get('url', 'Unknown URL')
            },
            'image': character.get('image', 'Unknown image'),
            'url': character.get('url', 'Unknown url'),
            'created': character.get('created', 'Unknown created')
        } for personaje in datos.get('results', [])]
        # Retornar información
        return personajes
    except KeyError as e:
        logger.error(f"Error al procesar los datos: {e}")
        raise

def lambda_handler(event, context):
    # Función principal 
    try:
        # Obtener datos de la Api a través del método
        datos = buscar_personajes()
        
        #Procesar los datos obtenidos
        personajes = procesar_personajes(datos)
        
        # Retornar los datos 
        return {
            'statusCode': 200,
            'body': json.dumbs({
                'mensaje': 'Los personajes han cargado correctamente',
                'personajes': personajes
            }),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
    except Exception as e:
        #Procesar error general 
        return {
            'statusCode': 500,
            'body': json.dumps({
                'mensaje': 'Error al obtener los datos',
                'error': 'Internal Server Error'
            }),
            'headers': {
                'Content-Type': 'application/json'
            }
        }
